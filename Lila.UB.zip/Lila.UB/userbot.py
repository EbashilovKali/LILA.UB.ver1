import os
import importlib.util
from telethon import TelegramClient, events
from colorama import init, Fore
import asyncio

# Инициализация цветов
init()
GREEN = Fore.GREEN
RED = Fore.RED
CYAN = Fore.CYAN
YELLOW = Fore.YELLOW
RESET = Fore.RESET

# Константы
ACTIVE_SESS_FILE = os.path.join("active", "active_sess.txt")
MODULES_DIR = "modules"

class UserBot:
    def __init__(self):
        self.client = None
        self.commands = {}
        self.loaded_modules = []

    def load_session(self):
        """Загрузка данных сессии из файла"""
        if not os.path.exists(ACTIVE_SESS_FILE):
            print(f"{RED}Ошибка: Файл сессии не найден!{RESET}")
            return None
        
        session_data = {}
        with open(ACTIVE_SESS_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                if ':' in line:
                    key, value = line.split(':', 1)
                    session_data[key.strip()] = value.strip()
        
        return session_data

    async def load_modules(self):
        """Загрузка модулей из папки modules"""
        if not os.path.exists(MODULES_DIR):
            print(f"{YELLOW}Папка с модулями не найдена, создаю...{RESET}")
            os.makedirs(MODULES_DIR)
            return

        for module_folder in os.listdir(MODULES_DIR):
            module_path = os.path.join(MODULES_DIR, module_folder)
            
            if not os.path.isdir(module_path):
                continue

            # Проверяем наличие description.txt
            desc_file = os.path.join(module_path, "description.txt")
            if not os.path.exists(desc_file):
                print(f"{YELLOW}Пропускаем {module_folder}: нет description.txt{RESET}")
                continue

            # Читаем описание модуля
            try:
                with open(desc_file, 'r', encoding='utf-8') as f:
                    lines = [line.strip() for line in f.readlines()]
                    if len(lines) < 3:
                        print(f"{RED}Ошибка в {desc_file}: недостаточно строк{RESET}")
                        continue
                    module_info = {
                        'name': lines[0],
                        'description': lines[1],
                        'command': lines[2],
                        'folder': module_folder
                    }
            except Exception as e:
                print(f"{RED}Ошибка чтения {desc_file}: {e}{RESET}")
                continue

            # Ищем .py файлы
            py_files = [f for f in os.listdir(module_path) if f.endswith('.py')]
            if not py_files:
                print(f"{YELLOW}Пропускаем {module_folder}: нет .py файлов{RESET}")
                continue

            # Загружаем модули
            for py_file in py_files:
                try:
                    file_path = os.path.join(module_path, py_file)
                    module_name = f"{module_folder}.{py_file[:-3]}"
                    
                    spec = importlib.util.spec_from_file_location(module_name, file_path)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    
                    if hasattr(module, 'register'):
                        await module.register(self)
                        self.loaded_modules.append(module_info)
                        print(f"{GREEN}Модуль {module_info['name']} успешно загружен{RESET}")
                except Exception as e:
                    print(f"{RED}Ошибка загрузки модуля {py_file}: {e}{RESET}")

    async def start(self):
        """Запуск юзербота"""
        print(f"{CYAN}Запуск LILA.UB UserBot{RESET}\n")
        
        session_data = self.load_session()
        if not session_data:
            return
        
        try:
            self.client = TelegramClient(
                'lila_session',
                int(session_data.get('API_ID', 0)),
                session_data.get('API_HASH', '')
            )
            
            phone = session_data.get('NUMBER', '')
            password = session_data.get('PASSWORD', None)
            
            await self.client.start(phone, password=password)
            print(f"{GREEN}Юзербот успешно запущен!{RESET}")
            
            # Загружаем модули
            await self.load_modules()
            
            # Регистрируем обработчики
            self.register_handlers()
            
            await self.client.run_until_disconnected()
            
        except Exception as e:
            print(f"{RED}Ошибка при запуске юзербота: {e}{RESET}")

    def register_handlers(self):
        """Регистрация обработчиков команд"""
        
        @self.client.on(events.NewMessage(outgoing=True, pattern=r'^\.(help|modules)$'))
        async def help_handler(event):
            """Обработчик команд помощи"""
            cmd = event.pattern_match.group(1)
            
            if cmd == "help":
                help_text = [
                    f"{CYAN}Доступные команды:{RESET}",
                    f"{GREEN}.help{RESET} - Показать это сообщение",
                    f"{GREEN}.modules{RESET} - Список загруженных модулей",
                    "",
                    f"{YELLOW}Модульные команды:{RESET}"
                ]
                
                for cmd, desc in self.commands.items():
                    help_text.append(f"{GREEN}.{cmd}{RESET} - {desc}")
                
                await event.edit("\n".join(help_text))
            
            elif cmd == "modules":
                if not self.loaded_modules:
                    await event.edit(f"{YELLOW}Нет загруженных модулей{RESET}")
                else:
                    modules_list = []
                    for module in self.loaded_modules:
                        modules_list.append(
                            f"{GREEN}[ {module['command']} ]{RESET} {module['name']}\n"
                            f"Описание: {module['description']}\n"
                            f"Папка: {module['folder']}"
                        )
                    await event.edit(f"{CYAN}Загруженные модули:{RESET}\n\n" + "\n\n".join(modules_list))

    def add_command(self, command, description):
        """Добавление команды из модуля"""
        self.commands[command] = description

if __name__ == "__main__":
    bot = UserBot()
    asyncio.run(bot.start())