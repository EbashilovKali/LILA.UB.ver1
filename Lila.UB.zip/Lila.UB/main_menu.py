import os
import subprocess
import sys
from colorama import init, Fore

# Инициализация цветов
init()
GREEN = Fore.GREEN
RED = Fore.RED
CYAN = Fore.CYAN
YELLOW = Fore.YELLOW
RESET = Fore.RESET

# Константы
ACTIVE_DIR = "active"
MODULES_DIR = "modules"  # Исправлено на modules
ACTIVE_SESS_FILE = os.path.join(ACTIVE_DIR, "active_sess.txt")

def clear_screen():
    """Очистка экрана консоли"""
    os.system('cls' if os.name == 'nt' else 'clear')

def display_menu():
    """Отображение главного меню"""
    clear_screen()
    print(f"{CYAN}╔════════════════════════════╗")
    print(f"║{YELLOW}        L I L A . U B       {CYAN}║")
    print(f"╚════════════════════════════╝{RESET}")
    print(f"\n{GREEN}[ 1 ]{RESET} Запустить Юзербот")
    print(f"{GREEN}[ 2 ]{RESET} Настройки сессии")
    print(f"{GREEN}[ 3 ]{RESET} Установленные модули")
    print(f"{GREEN}[ 4 ]{RESET} Выход\n")

def create_active_dir():
    """Создание необходимых директорий"""
    if not os.path.exists(ACTIVE_DIR):
        os.makedirs(ACTIVE_DIR)
    if not os.path.exists(MODULES_DIR):  # Теперь создает modules
        os.makedirs(MODULES_DIR)

def option1():
    """Запуск юзербота"""
    print(f"\n{YELLOW}Запуск юзербота...{RESET}")
    if not os.path.exists(ACTIVE_SESS_FILE):
        print(f"{RED}Ошибка: Файл сессии не найден!{RESET}")
        print("Сначала настройте сессию через пункт меню 2")
        input("\nНажмите Enter чтобы продолжить...")
        return
    
    try:
        # Добавляем аргумент для активации модулей
        subprocess.run([sys.executable, "userbot.py", "--modules"])
    except FileNotFoundError:
        print(f"{RED}Ошибка: Основной файл юзербота (userbot.py) не найден!{RESET}")
    input("\nНажмите Enter чтобы продолжить...")

def option2():
    """Настройки сессии"""
    create_active_dir()
    print(f"\n{YELLOW}Настройки сессии{RESET}")
    print(f"Файл сессии: {ACTIVE_SESS_FILE}\n")
    
    api_id = input("Введите API_ID: ").strip()
    api_hash = input("Введите API_HASH: ").strip()
    number = input("Введите номер телефона (с кодом страны): ").strip()
    password = input("Введите пароль (если есть, иначе оставьте пустым): ").strip()
    
    with open(ACTIVE_SESS_FILE, 'w', encoding='utf-8') as f:
        f.write(f"API_ID: {api_id}\n")
        f.write(f"API_HASH: {api_hash}\n")
        f.write(f"NUMBER: {number}\n")
        if password:
            f.write(f"PASSWORD: {password}\n")
    
    print(f"\n{GREEN}Настройки сессии сохранены!{RESET}")
    input("\nНажмите Enter чтобы продолжить...")

def option3():
    """Просмотр установленных модулей"""
    print(f"\n{YELLOW}Установленные модули{RESET}")
    create_active_dir()
    
    modules = []
    for module_name in os.listdir(MODULES_DIR):
        module_path = os.path.join(MODULES_DIR, module_name)
        
        if os.path.isdir(module_path):
            desc_file = os.path.join(module_path, "description.txt")
            py_files = [f for f in os.listdir(module_path) if f.endswith('.py')]
            
            if os.path.exists(desc_file) and py_files:
                try:
                    with open(desc_file, 'r', encoding='utf-8') as f:
                        lines = [line.strip() for line in f.readlines()]
                        if len(lines) >= 3:
                            modules.append({
                                'name': lines[0],
                                'description': lines[1],
                                'command': lines[2],
                                'main_file': py_files[0]  # Берем первый .py файл
                            })
                except Exception as e:
                    print(f"{RED}Ошибка чтения {desc_file}: {e}{RESET}")
    
    if not modules:
        print(f"{YELLOW}Нет установленных модулей{RESET}")
    else:
        print(f"\n{GREEN}Доступные модули:{RESET}\n")
        for i, module in enumerate(modules, 1):
            print(f"{GREEN}[ {i} ]{RESET} {module['name']}")
            print(f"   Описание: {module['description']}")
            print(f"   Команда: {module['command']}")
            print(f"   Файл: {module['main_file']}\n")
    
    input("\nНажмите Enter чтобы продолжить...")

def main():
    """Главная функция меню"""
    create_active_dir()
    while True:
        display_menu()
        choice = input(f"{YELLOW}Выберите пункт меню (1-4): {RESET}").strip()
        
        if choice == '1':
            option1()
        elif choice == '2':
            option2()
        elif choice == '3':
            option3()
        elif choice == '4':
            print(f"\n{YELLOW}Выход из программы...{RESET}")
            break
        else:
            print(f"\n{RED}Неверный выбор! Пожалуйста, введите число от 1 до 4{RESET}")
            input("\nНажмите Enter чтобы продолжить...")

if __name__ == "__main__":
    main()