import re
import requests
from bs4 import BeautifulSoup
from telethon import events
from datetime import datetime
import asyncio

async def register(bot):
    """Регистрация модуля"""
    bot.add_command("numbercheck", "Проверить информацию о номере телефона")

    @bot.client.on(events.NewMessage(outgoing=True, pattern=r'^\.numbercheck\s+(?:\+?(\d{1,3}))?[\s-]?(\d{3})[\s-]?(\d{3})[\s-]?(\d{4})$'))
    async def numbercheck_handler(event):
        """Обработчик команды .numbercheck"""
        try:
            # Извлекаем номер из команды
            match = event.pattern_match
            country_code = match.group(1) or ""
            area_code = match.group(2)
            first_part = match.group(3)
            second_part = match.group(4)
            
            # Форматируем номер
            phone_number = f"{country_code}{area_code}{first_part}{second_part}"
            clean_number = re.sub(r'[^\d]', '', phone_number)
            
            await event.edit(f"🔍 Проверяю номер: {clean_number}...")
            
            # URL для проверки
            url = f"https://getscam.com/{clean_number}"
            
            # Имитируем браузерные заголовки
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            
            # Получаем данные с сайта
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            
            # Парсим HTML
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Извлекаем нужную информацию
            result = {
                "Номер": clean_number,
                "Состояние": "Не найдено",
                "Тип": "Не найдено",
                "IP Адрес": "Не найдено",
                "Сайт Оператора": "Не найдено",
                "Оператор": "Не найдено",
                "Страна": "Не найдено",
                "Город": "Не найдено"
            }
            
            # Новый метод парсинга - ищем элементы по тексту
            def find_info(label):
                element = soup.find(string=re.compile(label))
                if element:
                    # Берем следующий элемент после метки
                    value = element.find_next(string=True)
                    return value.strip() if value else "Не найдено"
                return "Не найдено"
            
            # Обновляем результаты
            result.update({
                "Состояние": find_info("Состояние"),
                "Тип": find_info("Тип"),
                "IP Адрес": find_info("IP Адрес"),
                "Сайт Оператора": find_info("Сайт Оператора"),
                "Оператор": find_info("Оператор"),
                "Страна": find_info("Страна"),
                "Город": find_info("Город")
            })
            
            # Формируем ответ
            response_text = [
                f"📋 Результаты проверки номера: +{clean_number}",
                f"🔗 Источник: {url}",
                "",
                f"📱 Номер: {result['Номер']}",
                f"🟢 Состояние: {result['Состояние']}",
                f"📌 Тип: {result['Тип']}",
                f"🌐 IP Адрес: {result['IP Адрес']}",
                f"🏢 Оператор: {result['Оператор']}",
                f"🌍 Страна: {result['Страна']}",
                f"🏙️ Город: {result['Город']}",
                "",
                f"🕒 Время проверки: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            ]
            
            await event.edit("\n".join(response_text))
            
        except requests.exceptions.RequestException as e:
            await event.edit(f"⚠ Ошибка при запросе к сайту: {str(e)}")
        except Exception as e:
            await event.edit(f"⚠ Произошла ошибка: {str(e)}")