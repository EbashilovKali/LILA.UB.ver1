
import os
from telethon import events
from telethon.tl.types import User, UserStatusOnline, UserStatusOffline
from datetime import datetime
import asyncio
from jinja2 import Template
import logging

# Configure logging
logging.basicConfig(level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(message)s')


HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>USER INFO TG</title>
    <style>
        :root {
            --neon-color: #0fa;
            --bg-color: #121212;
            --card-bg: #1e1e1e;
            --text-color: #e0e0e0;
        }
        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            position: relative;
        }
        .header h1 {
            color: var(--neon-color);
            font-size: 3em;
            text-transform: uppercase;
            letter-spacing: 3px;
            text-shadow: 0 0 10px var(--neon-color), 
                         0 0 20px var(--neon-color), 
                         0 0 30px var(--neon-color);
            animation: flicker 1.5s infinite alternate;
        }
        @keyframes flicker {
            0%, 19%, 21%, 23%, 25%, 54%, 56%, 100% {
                text-shadow: 0 0 10px var(--neon-color),
                            0 0 20px var(--neon-color),
                            0 0 30px var(--neon-color);
            }
            20%, 24%, 55% {
                text-shadow: none;
            }
        }
        .profile-card {
            background-color: var(--card-bg);
            border-radius: 8px;
            padding: 30px;
            margin: 0 auto;
            max-width: 600px;
            box-shadow: 0 0 15px rgba(0, 255, 170, 0.1);
            border: 1px solid rgba(0, 255, 170, 0.1);
        }
        .info-row {
            display: flex;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #333;
        }
        .info-label {
            color: var(--neon-color);
            width: 150px;
            font-weight: bold;
        }
        .info-value {
            flex: 1;
        }
        .qr-code {
            margin: 20px auto;
            display: block;
            max-width: 200px;
            border: 2px solid var(--neon-color);
            border-radius: 8px;
        }
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-weight: bold;
            margin-left: 10px;
        }
        .premium {
            background-color: rgba(255, 215, 0, 0.2);
            color: gold;
        }
        .verified {
            background-color: rgba(0, 191, 255, 0.2);
            color: deepskyblue;
        }
        .bot {
            background-color: rgba(138, 43, 226, 0.2);
            color: blueviolet;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>USER INFO TG</h1>
        <p>Сохранено: {{ save_time }}</p>
    </div>

    <div class="profile-card">
        {% if user.photo %}
        <img src="{{ user.photo }}" style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; display: block; margin: 0 auto 20px; border: 3px solid var(--neon-color);">
        {% endif %}
        
        <div class="info-row">
            <div class="info-label">Имя:</div>
            <div class="info-value">{{ user.first_name }}</div>
        </div>
        
        {% if user.last_name and user.last_name != "Не найдено" %}
        <div class="info-row">
            <div class="info-label">Фамилия:</div>
            <div class="info-value">{{ user.last_name }}</div>
        </div>
        {% endif %}
        
        <div class="info-row">
            <div class="info-label">ID:</div>
            <div class="info-value">{{ user.id }}</div>
        </div>
        
        <div class="info-row">
            <div class="info-label">Username:</div>
            <div class="info-value">
                {% if user.username %}@{{ user.username }}{% else %}Не найдено{% endif %}
            </div>
        </div>
        
        <div class="info-row">
            <div class="info-label">Ссылка:</div>
            <div class="info-value">
                {% if user.username %}
                <a href="https://t.me/{{ user.username }}" style="color: var(--neon-color);">t.me/{{ user.username }}</a>
                {% else %}Не найдено{% endif %}
            </div>
        </div>
        
        <div class="info-row">
            <div class="info-label">Номер Телефона:</div>
            <div class="info-value">{{ user.phone or 'Скрыт' }}</div>
        </div>
        
        {% if user.about and user.about != "Не найдено" %}
        <div class="info-row">
            <div class="info-label">Описание:</div>
            <div class="info-value">{{ user.about }}</div>
        </div>
        {% endif %}
        
        <div class="info-row">
            <div class="info-label">Тип:</div>
            <div class="info-value">
                {% if user.bot %}Бот{% else %}Человек{% endif %}
                {% if user.bot %}<span class="badge bot">BOT</span>{% endif %}
            </div>
        </div>
        
        <div class="info-row">
            <div class="info-label">Онлайн:</div>
            <div class="info-value">
                {% if user.status %}
                    {% if user.status.__class__.__name__ == 'UserStatusOnline' %}
                        Сейчас онлайн
                    {% elif user.status.__class__.__name__ == 'UserStatusOffline' %}
                        Был(а) {{ user.status.was_online.strftime('%Y-%m-%d %H:%M:%S') }}
                    {% else %}
                        Неизвестно
                    {% endif %}
                {% else %}
                    Неизвестно
                {% endif %}
            </div>
        </div>
        
        <div class="info-row">
            <div class="info-label">Премиум:</div>
            <div class="info-value">
                {% if user.premium %}Да <span class="badge premium">PREMIUM</span>{% else %}Нет{% endif %}
            </div>
        </div>
        
        <div class="info-row">
            <div class="info-label">Верификация:</div>
            <div class="info-value">
                {% if user.verified %}Да <span class="badge verified">VERIFIED</span>{% else %}Нет{% endif %}
            </div>
        </div>
        
        {% if user.username %}
        <div class="info-row">
            <div class="info-label">QR код:</div>
            <div class="info-value">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https://t.me/{{ user.username }}" class="qr-code" alt="QR Code">
            </div>
        </div>
        {% endif %}
    </div>
</body>
</html>
"""

async def register(bot):
    """Регистрация модуля"""
    bot.add_command("user", "Получить полную информацию о пользователе")

    @bot.client.on(events.NewMessage(outgoing=True, pattern=r'^\.user(?:@\w+)?(?:\s+(.+))?$'))
    async def userinfo_handler(event):
        """Обработчик команды .user"""
        try:
            # Определяем целевого пользователя
            if event.is_reply:
                reply = await event.get_reply_message()
                user = await reply.get_sender()
            elif event.pattern_match.group(1):
                input_data = event.pattern_match.group(1).strip()
                try:
                    user = await bot.client.get_entity(input_data)
                except:
                    await event.edit("❌ Пользователь не найден!")
                    return
            else:
                user = await bot.client.get_me()

            if not isinstance(user, User):
                await event.edit("❌ Это не пользователь!")
                return

            await event.edit("🔍 Собираю информацию о пользователе...")

            # Получаем фото профиля
            photo_path = None
            try:
                if user.photo:
                    photo_bytes = await bot.client.download_profile_photo(user, file=bytes)
                    if photo_bytes:
                        photo_path = f"data:image/jpeg;base64,{photo_bytes.hex()}"
            except Exception as e:
                logging.error(f"Error downloading profile photo: {e}")
                photo_path = None  # Set to None if download fails

            # Подготавливаем данные для шаблона
            user_data = {
                "first_name": user.first_name or "Не найдено",
                "last_name": user.last_name or "Не найдено",
                "id": user.id or "Не найдено",
                "username": user.username or "Не найдено",
                "phone": user.phone or "Скрыт",
                "about": getattr(user, 'about', None) or "Не найдено", # Use getattr for safety
                "bot": user.bot or False,
                "status": user.status or None,
                "premium": user.premium or False,
                "verified": user.verified or False,
                "photo": photo_path
            }

            # Генерируем HTML
            template = Template(HTML_TEMPLATE)
            html = template.render(
                user=user_data,
                save_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            )

            # Сохраняем в файл
            os.makedirs("user_info", exist_ok=True)
            filename = f"user_info/{user.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
            
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(html)

            # Отправляем файл
            await event.delete()
            await bot.client.send_file(
                event.chat_id,
                filename,
                caption=f"📊 Полная информация о пользователе {'@' + user.username if user.username else user.first_name}",
                force_document=True
            )

            # Удаляем временный файл
            try:
                os.remove(filename)
            except Exception as e:
                logging.error(f"Error deleting temporary file: {e}")


        except Exception as e:
            logging.error(f"An error occurred: {e}", exc_info=True)  # Log the full exception
            await event.edit(f"⚠ Произошла ошибка: {str(e)}")

