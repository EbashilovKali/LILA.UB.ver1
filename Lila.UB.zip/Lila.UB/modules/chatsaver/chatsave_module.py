import os
from telethon import events
from datetime import datetime
from jinja2 import Template

# Шаблон HTML в темном стиле с неоновыми элементами
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHAT SAVER</title>
    <style>
        :root {
            --neon-color: #0fa;
            --bg-color: #121212;
            --card-bg: #1e1e1e;
            --text-color: #e0e0e0;
        }
        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            position: relative;
        }
        .header h1 {
            color: var(--neon-color);
            font-size: 3em;
            text-transform: uppercase;
            letter-spacing: 3px;
            text-shadow: 0 0 10px var(--neon-color), 
                         0 0 20px var(--neon-color), 
                         0 0 30px var(--neon-color);
            animation: flicker 1.5s infinite alternate;
        }
        @keyframes flicker {
            0%, 19%, 21%, 23%, 25%, 54%, 56%, 100% {
                text-shadow: 0 0 10px var(--neon-color),
                            0 0 20px var(--neon-color),
                            0 0 30px var(--neon-color);
            }
            20%, 24%, 55% {
                text-shadow: none;
            }
        }
        .section {
            background-color: var(--card-bg);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 0 15px rgba(0, 255, 170, 0.1);
            border: 1px solid rgba(0, 255, 170, 0.1);
        }
        .section-title {
            color: var(--neon-color);
            border-bottom: 1px solid var(--neon-color);
            padding-bottom: 10px;
            margin-top: 0;
        }
        .message {
            padding: 10px;
            border-bottom: 1px solid #333;
            margin-bottom: 10px;
        }
        .message-date {
            color: var(--neon-color);
            font-weight: bold;
            margin-bottom: 5px;
        }
        .user-card {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #333;
            margin-bottom: 15px;
        }
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 20px;
            border: 2px solid var(--neon-color);
        }
        .user-info {
            flex: 1;
        }
        .info-row {
            margin-bottom: 5px;
        }
        .info-label {
            color: var(--neon-color);
            display: inline-block;
            width: 150px;
        }
        .chat-info {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
        }
        .info-item {
            background-color: #252525;
            padding: 10px;
            border-radius: 5px;
        }
        .admin-badge {
            display: inline-block;
            background-color: rgba(0, 255, 170, 0.2);
            color: var(--neon-color);
            padding: 2px 8px;
            border-radius: 4px;
            margin-right: 5px;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>CHAT SAVER</h1>
        <p>Сохранено: {{ save_time }}</p>
    </div>

    <div class="section">
        <h2 class="section-title">Информация о чате</h2>
        <div class="chat-info">
            {% for item in chat_info %}
            <div class="info-item">
                <strong>{{ item.label }}:</strong> {{ item.value }}
            </div>
            {% endfor %}
        </div>
    </div>

    <div class="section">
        <h2 class="section-title">Пользователи ({{ users|length }})</h2>
        {% for user in users %}
        <div class="user-card">
            {% if user.photo %}
            <img src="{{ user.photo }}" class="user-avatar" alt="Аватар">
            {% else %}
            <div class="user-avatar" style="background-color: #333; display: flex; align-items: center; justify-content: center;">
                <span>No photo</span>
            </div>
            {% endif %}
            <div class="user-info">
                <div class="info-row"><span class="info-label">Ник:</span> {{ user.name }}</div>
                <div class="info-row"><span class="info-label">ID:</span> {{ user.id }}</div>
                <div class="info-row"><span class="info-label">Username:</span> {{ user.username or '—' }}</div>
                <div class="info-row"><span class="info-label">Телефон:</span> {{ user.phone or 'скрыто' }}</div>
                <div class="info-row"><span class="info-label">Дата вступления:</span> {{ user.join_date }}</div>
                {% if user.description %}
                <div class="info-row"><span class="info-label">Описание:</span> {{ user.description }}</div>
                {% endif %}
            </div>
        </div>
        {% endfor %}
    </div>

    <div class="section">
        <h2 class="section-title">Сообщения ({{ messages|length }})</h2>
        {% set ns = namespace(last_date=None) %}
        {% for msg in messages %}
            {% if msg.date != ns.last_date %}
                <div class="message-date">{{ msg.date }}</div>
                {% set ns.last_date = msg.date %}
            {% endif %}
            <div class="message">
                <strong>[ {{ msg.sender_name }} | {{ msg.sender_id }} ]</strong>: {{ msg.text }}
            </div>
        {% endfor %}
    </div>
</body>
</html>
"""

async def register(bot):
    """Регистрация модуля"""
    bot.add_command("chatsave", "Сохранить информацию о чате в HTML файл")

    @bot.client.on(events.NewMessage(outgoing=True, pattern=r'^\.chatsave$'))
    async def chatsave_handler(event):
        """Обработчик команды .chatsave"""
        if not event.is_reply:
            await event.edit("❌ Ответьте на сообщение из чата, который хотите сохранить!")
            return

        try:
            msg = await event.get_reply_message()
            chat = await bot.client.get_entity(msg.chat_id)
            
            await event.edit("⏳ Собираю информацию о чате...")
            
            # 1. Информация о чате
            chat_info = []
            if hasattr(chat, 'title'):
                chat_info.append({"label": "Название", "value": chat.title})
            
            if hasattr(chat, 'date'):
                chat_info.append({
                    "label": "Дата создания", 
                    "value": chat.date.strftime('%Y-%m-%d %H:%M:%S')
                })
            
            if hasattr(chat, 'participants_count'):
                chat_info.append({
                    "label": "Участников", 
                    "value": chat.participants_count
                })
            
            if hasattr(chat, 'username'):
                chat_info.append({
                    "label": "Ссылка", 
                    "value": f"https://t.me/{chat.username}"
                })
            else:
                chat_info.append({"label": "Тип", "value": "Личный чат"})
            
            # 2. Собираем информацию о пользователях
            users = []
            async for user in bot.client.iter_participants(chat):
                user_data = {
                    "id": user.id,
                    "name": user.first_name,
                    "username": user.username,
                    "phone": user.phone,
                    "join_date": "Неизвестно",
                    "description": None,
                    "photo": None
                }
                
                if user.last_name:
                    user_data["name"] += f" {user.last_name}"
                
                if hasattr(user, 'about'):
                    user_data["description"] = user.about
                
                # Пытаемся получить фото
                if user.photo:
                    photo = await bot.client.download_profile_photo(user, file=bytes)
                    if photo:
                        user_data["photo"] = f"data:image/jpeg;base64,{photo.hex()}"
                
                users.append(user_data)
            
            # 3. Собираем сообщения
            messages = []
            async for message in bot.client.iter_messages(chat, limit=200):
                sender = await message.get_sender()
                sender_name = sender.first_name if sender else "Неизвестно"
                if sender and sender.last_name:
                    sender_name += f" {sender.last_name}"
                
                messages.append({
                    "date": message.date.strftime('%Y-%m-%d'),
                    "sender_name": sender_name,
                    "sender_id": sender.id if sender else 0,
                    "text": message.text or "[медиа]"
                })
            
            # Генерируем HTML
            template = Template(HTML_TEMPLATE)
            html = template.render(
                save_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                chat_info=chat_info,
                users=users,
                messages=messages
            )
            
            # Сохраняем в файл
            os.makedirs("chat_saves", exist_ok=True)
            filename = f"chat_saves/{chat.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(html)
            
            await event.edit(f"✅ Чат сохранен в файл: `{filename}`")
            
        except Exception as e:
            await event.edit(f"⚠ Ошибка: {str(e)}")