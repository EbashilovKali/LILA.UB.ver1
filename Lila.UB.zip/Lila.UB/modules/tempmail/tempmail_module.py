import random
import string
import time
from aiohttp import web
from telethon import events
from datetime import datetime, timedelta

# Конфигурация
TEMP_MAIL_DOMAIN = "1secmail.com"
SESSION_TIMEOUT = 600  # 10 минут
CHECK_INTERVAL = 10     # Проверка писем каждые 10 секунд

async def register(bot):
    """Регистрация модуля временной почты"""
    bot.temp_mails = {}  # Хранилище почт: {email: {data}}
    bot.add_command("tempmail", "Создать временный почтовый ящик")

    # Запуск HTTP сервера
    runner = web.AppRunner(await create_site(bot))
    await runner.setup()
    site = web.TCPSite(runner, 'localhost', 8080)
    await site.start()

    @bot.client.on(events.NewMessage(outgoing=True, pattern=r'^\.tempmail$'))
    async def tempmail_handler(event):
        """Обработчик команды .tempmail"""
        # Генерируем случайный email
        username = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
        email = f"{username}@{TEMP_MAIL_DOMAIN}"
        expire_time = datetime.now() + timedelta(seconds=SESSION_TIMEOUT)
        
        # Сохраняем в хранилище
        bot.temp_mails[email] = {
            'expires': expire_time,
            'messages': [],
            'last_check': datetime.now()
        }
        
        # Формируем ссылку
        link = f"http://localhost:8080/mail?email={email}"
        await event.edit(f"📧 Ваш временный почтовый ящик:\n{email}\n{link}")

async def create_site(bot):
    """Создание aiohttp приложения"""
    app = web.Application()
    app.add_routes([
        web.get('/', handle_index),
        web.get('/mail', handle_mail),
        web.get('/inbox', handle_inbox),
        web.get('/message/{msg_id}', handle_message)
    ])
    app['bot'] = bot
    return app

async def handle_index(request):
    """Главная страница"""
    return web.Response(text="Temp Mail Service", content_type='text/html')

async def handle_mail(request):
    """Страница почтового ящика"""
    email = request.query.get('email')
    if email not in request.app['bot'].temp_mails:
        return web.Response(text="Почта не найдена", status=404)

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Temp Mail - {email}</title>
        <style>
            body {{
                background: #0a0a0a;
                color: #00ff00;
                font-family: 'Courier New', monospace;
                margin: 0;
                padding: 20px;
            }}
            .header {{
                text-align: center;
                font-size: 2em;
                text-shadow: 0 0 10px #00ff00;
                margin-bottom: 30px;
            }}
            .panel {{
                background: #1a1a1a;
                border: 1px solid #00ff00;
                border-radius: 5px;
                padding: 20px;
                margin-bottom: 20px;
                box-shadow: 0 0 15px #00ff0080;
            }}
            .email-box {{
                display: flex;
                align-items: center;
                gap: 10px;
                font-size: 1.2em;
            }}
            button {{
                background: #002200;
                color: #00ff00;
                border: 1px solid #00ff00;
                padding: 5px 15px;
                border-radius: 3px;
                cursor: pointer;
                transition: all 0.3s;
            }}
            button:hover {{
                background: #004400;
                box-shadow: 0 0 10px #00ff00;
            }}
            .messages-list {{
                list-style: none;
                padding: 0;
            }}
            .message-item {{
                padding: 10px;
                border-bottom: 1px solid #00ff00;
                cursor: pointer;
            }}
            .timer {{
                color: #ff5555;
                font-size: 0.9em;
            }}
        </style>
    </head>
    <body>
        <div class="header">📧 Temp Mail</div>
        
        <div class="panel">
            <div class="email-box">
                <span id="email">{email}</span>
                <button onclick="copyEmail()">Копировать</button>
                <span class="timer" id="timer">{SESSION_TIMEOUT}</span>
            </div>
        </div>

        <div class="panel">
            <h3>📨 Сообщения:</h3>
            <ul class="messages-list" id="messages"></ul>
        </div>

        <script>
            let timeLeft = {SESSION_TIMEOUT};
            
            function updateTimer() {{
                timeLeft--;
                document.getElementById('timer').textContent = timeLeft;
                if(timeLeft <= 0) location.reload();
            }}
            
            setInterval(updateTimer, 1000);
            
            async function loadMessages() {{
                const response = await fetch('/inbox?email={email}');
                const messages = await response.json();
                const list = document.getElementById('messages');
                list.innerHTML = messages.map(msg => `
                    <li class="message-item" onclick="location.href='/message/${{msg.id}}?email={email}'">
                        <strong>${{msg.from}}</strong> - ${{msg.subject}}
                    </li>
                `).join('');
            }}
            
            function copyEmail() {{
                navigator.clipboard.writeText('{email}');
                alert('Email скопирован!');
            }}
            
            // Первая загрузка и обновление каждые {CHECK_INTERVAL} секунд
            loadMessages();
            setInterval(loadMessages, {CHECK_INTERVAL * 1000});
        </script>
    </body>
    </html>
    """
    return web.Response(text=html, content_type='text/html')

async def handle_inbox(request):
    """Получение списка писем"""
    email = request.query.get('email')
    bot = request.app['bot']
    
    if email not in bot.temp_mails:
        return web.json_response([])

    # Проверяем API 1secmail
    async with request.app['bot'].client.session.get(
        f"https://www.1secmail.com/api/v1/?action=getMessages&login={email.split('@')[0]}&domain={TEMP_MAIL_DOMAIN}"
    ) as resp:
        messages = await resp.json()

    # Сохраняем новые письма
    for msg in messages:
        if msg['id'] not in [m['id'] for m in bot.temp_mails[email]['messages']]:
            bot.temp_mails[email]['messages'].append(msg)
    
    return web.json_response(bot.temp_mails[email]['messages'])

async def handle_message(request):
    """Просмотр полного письма"""
    email = request.query.get('email')
    msg_id = request.match_info['msg_id']
    
    # Получаем письмо через API
    async with request.app['bot'].client.session.get(
        f"https://www.1secmail.com/api/v1/?action=readMessage&login={email.split('@')[0]}&domain={TEMP_MAIL_DOMAIN}&id={msg_id}"
    ) as resp:
        message = await resp.json()

    html = f"""
    <div style="padding: 20px; background: #1a1a1a; color: #00ff00;">
        <h2>{message['subject']}</h2>
        <p>От: {message['from']}</p>
        <p>Дата: {message['date']}</p>
        <div style="border-top: 1px solid #00ff00; margin: 20px 0; padding: 15px;">
            {message['textBody']}
        </div>
        <button onclick="window.history.back()">Назад</button>
    </div>
    """
    return web.Response(text=html, content_type='text/html')