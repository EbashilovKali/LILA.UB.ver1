import asyncio
from telethon import events

async def register(bot):
    """Регистрация модуля анимаций с функцией остановки"""
    bot.active_animations = {}  # {chat_id: event}
    bot.add_command("animate", "Запустить/остановить анимацию")

    @bot.client.on(events.NewMessage(outgoing=True, pattern=r'^\.animate(?: |$)(.*)'))
    async def animate_handler(event):
        """Обработчик анимаций"""
        args = event.pattern_match.group(1).strip().lower()
        
        # Обработка команды остановки
        if args == "stop":
            chat_id = event.chat_id
            if chat_id in bot.active_animations:
                bot.active_animations[chat_id].set()
                del bot.active_animations[chat_id]
                await event.edit("⏹ Анимация остановлена!")
            else:
                await event.edit("⚠ Нет активных анимаций для остановки")
            return

        # Запуск анимации
        try:
            chat_id = event.chat_id
            if chat_id in bot.active_animations:
                await event.edit("⏳ Пожалуйста, дождитесь завершения текущей анимации")
                return

            animation_type = args or "run"
            stop_event = asyncio.Event()
            bot.active_animations[chat_id] = stop_event

            # Конфигурация анимаций
            animations = {
                "run": ["🏃", "🏃♂️", "🏃♀️", "🚶", "🕴"],
                "spin": ["🌀", "🌪️", "💫", "✨", "⚡"],
                "heart": ["❤️", "🧡", "💛", "💚", "💙", "💜"],
                "moon": ["🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘"],
                "clock": ["🕛", "🕐", "🕑", "🕒", "🕓", "🕔", "🕕", "🕖", "🕗", "🕘", "🕙", "🕚"],
                "fire": ["🔥", "🌟", "💥", "☄️", "🌠"]
            }
            
            frames = animations.get(animation_type, animations["run"])
            speed = 0.3
            
            msg = await event.edit("🚀 Запуск анимации...")
            await asyncio.sleep(1)

            frame_count = 0
            while not stop_event.is_set():
                for frame in frames:
                    if stop_event.is_set():
                        break
                    await msg.edit(f"**{animation_type.upper()}**\n{frame}\n`Цикл: {frame_count+1}`")
                    await asyncio.sleep(speed)
                frame_count += 1

            await msg.edit("⏹ Анимация прервана!")
            
        except Exception as e:
            await event.edit(f"⚠ Ошибка: {str(e)}")
        finally:
            if chat_id in bot.active_animations:
                del bot.active_animations[chat_id]